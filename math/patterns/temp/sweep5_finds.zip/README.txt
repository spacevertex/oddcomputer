5-particle sweep finds (no bobos), all verified in bobo.html. Every one is a
single interacting group: no separate oscillators sitting side by side.

NewFinds5/ drops straight into patterns/; run update-manifest.sh afterwards.
  Orbiters5         4  quarter-turn orbiters (all compact, 15-27 across)
  HalfTurn5_large  14  half-turn travellers, span >= 100 (mostly long braided shuttles)
  HalfTurn5_small 118  half-turn travellers, span < 100
  Spinners5        97  half-turn patterns that spin in place without travelling

File names give the shape period (one full lap). In 11 files the particles
trade places, so the Zoo badge shows 3x that number. n5_halfturn_p846 is a
perfectly straight shuttle about 2060 long and 2 wide, so it looks like a
bare line in the contact sheet.

Stages covered: radius 2 with speeds up to 1; starts at rest with radius 3
to 10; radius 3 with speeds up to 1.
